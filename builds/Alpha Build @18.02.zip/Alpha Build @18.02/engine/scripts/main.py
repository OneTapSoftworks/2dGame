import debug

debug.log("Python core loaded!")